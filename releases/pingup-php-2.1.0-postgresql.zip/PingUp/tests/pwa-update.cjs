"use strict";
const assert = require("assert/strict"),
  fs = require("fs"),
  path = require("path"),
  os = require("os"),
  crypto = require("crypto"),
  { spawn } = require("child_process");
const { chromium } = require("playwright");
(async () => {
  const root = path.resolve(__dirname, ".."),
    fixture = fs.mkdtempSync(path.join(os.tmpdir(), "pingup-update-"));
  fs.cpSync(path.join(root, "public"), path.join(fixture, "public"), { recursive: true });
  fs.symlinkSync(path.join(root, "src"), path.join(fixture, "src"), "dir");
  const php = process.env.PINGUP_PHP_BINARY || "php";
  const log = fs.openSync(path.join(fixture, "server.log"), "w");
  const server = spawn(php, ["-S", "127.0.0.1:8187", "-t", "public"], {
    cwd: fixture,
    env: { ...process.env, PINGUP_STORAGE_PATH: path.join(fixture, "private"), PINGUP_SECURE_COOKIES: "0", PINGUP_MAX_USERS: "0" },
    stdio: ["ignore", log, log],
  });
  let browser;
  try {
    const base = "http://127.0.0.1:8187/";
    for (let i = 0; i < 40; i++) {
      try {
        await fetch(base);
        break;
      } catch {
        await new Promise((r) => setTimeout(r, 100));
      }
    }
    browser = await chromium.launch({
      executablePath: process.env.PINGUP_BROWSER_EXECUTABLE || "/usr/bin/chromium",
      headless: true,
      args: ["--no-sandbox"],
    });
    const context = await browser.newContext();
    const guest = await context.request.get(base + "api.php?action=bootstrap").then((r) => r.json());
    const response = await context.request
      .post(base + "api.php?action=auth.register", {
        headers: { "X-CSRF-Token": guest.data.csrf },
        data: {
          name: "Update QA",
          username: "update" + crypto.randomBytes(4).toString("hex"),
          password: crypto.randomBytes(24).toString("base64url"),
        },
      })
      .then((r) => r.json());
    assert(response.ok);
    const page = await context.newPage();
    await page.goto(base);
    await page.locator(".app-shell").waitFor();
    await page.evaluate(() => navigator.serviceWorker.ready.then(() => true));
    await page.waitForFunction(() => !!navigator.serviceWorker.controller);
    const file = path.join(fixture, "public/sw.js");
    const source = fs.readFileSync(file, "utf8");
    const version = /VERSION='([^']+)'/.exec(source)[1];
    fs.writeFileSync(file, source.replace(`VERSION='${version}'`, `VERSION='${version}-update-test'`));
    await page.evaluate(async () => {
      const r = await navigator.serviceWorker.ready;
      await r.update();
    });
    await page.locator("#pwa-update").waitFor({ timeout: 10000 });
    await page.evaluate(() => window.PingUpExperience.call({ id: 123, incoming: true, status: "ringing" }));
    await page.locator("#pwa-update").click();
    assert(await page.locator("#pwa-update").count());
    assert((await page.evaluate(() => caches.keys())).includes(`pingup-static-${version}`));
    await page.evaluate(() => window.PingUpExperience.callEnd());
    await Promise.all([page.waitForEvent("load"), page.locator("#pwa-update").click()]);
    await page.locator(".app-shell").waitFor();
    const keys = await page.evaluate(() => caches.keys());
    assert(keys.includes(`pingup-static-${version}-update-test`));
    assert(!keys.includes(`pingup-static-${version}`));
    console.log(
      "PASS: actual SW update in disposable fixture; waiting update UI; active-call guard; explicit activation; cache version cleanup; authorization retained.",
    );
  } finally {
    await browser?.close();
    server.kill();
    fs.closeSync(log);
  }
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
