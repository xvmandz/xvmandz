"use strict";
const assert = require("assert/strict"),
  crypto = require("crypto");
const { chromium } = require("playwright");
(async () => {
  const browser = await chromium.launch({
    executablePath: process.env.PINGUP_BROWSER_EXECUTABLE || "/usr/bin/chromium",
    headless: true,
    args: ["--no-sandbox"],
  });
  try {
    const base = process.env.PINGUP_TEST_URL || "http://127.0.0.1:8184/";
    assert(["localhost", "127.0.0.1"].includes(new URL(base).hostname));
    const users = [];
    for (let i = 0; i < 2; i++) {
      const context = await browser.newContext({ permissions: ["notifications"] });
      const guest = await context.request.get(base + "api.php?action=bootstrap").then((r) => r.json());
      const data = await context.request
        .post(base + "api.php?action=auth.register", {
          headers: { "X-CSRF-Token": guest.data.csrf },
          data: {
            username: "pwa" + crypto.randomBytes(5).toString("hex"),
            name: "PWA QA " + i,
            password: crypto.randomBytes(24).toString("base64url"),
            locale: "en",
          },
        })
        .then((r) => r.json());
      assert(data.ok);
      const user = { context, ...data.data };
      user.api = async (action, params = {}, post = false) => {
        const url = new URL("api.php", base);
        url.searchParams.set("action", action);
        if (!post) for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
        const result = await (
          post ? context.request.post(url.href, { headers: { "X-CSRF-Token": user.csrf }, data: params }) : context.request.get(url.href)
        ).then((r) => r.json());
        assert(result.ok, action);
        return result.data;
      };
      users.push(user);
    }
    const [a, b] = users,
      conversation = await a.api("conversations.create", { type: "direct", user_id: b.user.id }, true);
    await b.api("notifications.settings", { system: true, preview: false }, true);
    const page = await b.context.newPage();
    await page.goto(base);
    await page.locator(".app-shell").waitFor();
    await page.evaluate(() => navigator.serviceWorker.ready.then(() => true));
    await page.waitForFunction(() => !!navigator.serviceWorker.controller);
    const worker = b.context.serviceWorkers()[0];
    await worker.evaluate(() => {
      self.__testShown = [];
      const original = self.registration.showNotification.bind(self.registration);
      self.registration.showNotification = (title, options) => {
        self.__testShown.push({ title, body: options.body, data: options.data });
        return original(title, options);
      };
    });
    const blank = await b.context.newPage();
    await blank.goto("about:blank");
    await blank.bringToFront();
    const message = await a.api(
      "messages.send",
      { conversation_id: conversation.id, text: "SECRET_NOTIFICATION_TEXT", client_id: "pwa:" + crypto.randomUUID() },
      true,
    );
    const notifications = await b.api("notifications.list", { after_event_id: 0 });
    const event = notifications.events.find((e) => e.conversation_id === conversation.id);
    await page.evaluate(
      ({ event, user }) => navigator.serviceWorker.controller.postMessage({ type: "notify", event_id: event.event_id, user_id: user }),
      { event, user: b.user.id },
    );
    for (let i = 0; i < 30 && !(await worker.evaluate(() => self.__testShown.length)); i++) await page.waitForTimeout(200);
    const system = await worker.evaluate(() => self.__testShown[0]);
    assert(system, "Worker never called showNotification");
    assert.equal(system.title, a.user.name);
    assert(!system.body.includes("SECRET_NOTIFICATION_TEXT"));
    assert.equal(system.data.conversation_id, conversation.id);
    await page.evaluate(
      ({ event, user }) => navigator.serviceWorker.controller.postMessage({ type: "notify", event_id: event.event_id, user_id: user }),
      { event, user: b.user.id },
    );
    await page.waitForTimeout(500);
    assert.equal(await worker.evaluate(() => self.__testShown.length), 1);
    await b.api("conversations.read", { conversation_id: conversation.id, last_message_id: message.id }, true);
    await page.evaluate((id) => window.PingUpExperience.chatRead(id), conversation.id);
    await page.waitForFunction(async () => !(await (await navigator.serviceWorker.ready).getNotifications()).length);
    const cacheURLs = await page.evaluate(async () => {
      const urls = [];
      for (const key of await caches.keys()) for (const req of await (await caches.open(key)).keys()) urls.push(req.url);
      return urls;
    });
    assert(!cacheURLs.some((url) => /api\.php|media\.php|index\.php/.test(url)));
    await page.bringToFront();
    await b.context.setOffline(true);
    await page.reload();
    await page.locator("#offline-title").waitFor();
    await page.waitForFunction(() => !!document.querySelector("#offline-retry")?.textContent);
    await b.context.setOffline(false);
    // offline.js reloads by itself on the "online" event; the Retry button is only needed if that has not happened yet.
    await page.locator("#offline-retry").click({ timeout: 1500 }).catch(() => {});
    await page.locator(".app-shell").waitFor({ timeout: 15000 });
    console.log(
      "PASS: Service Worker showNotification call while tab inactive (instrumented, original API also invoked); privacy; dedup; read closure; static-only cache; offline recovery with valid session. No real provider Push delivery or Android installation was exercised.",
    );
  } finally {
    await browser.close();
  }
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
